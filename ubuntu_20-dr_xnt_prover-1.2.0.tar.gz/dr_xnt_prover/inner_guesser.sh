#!/bin/bash

# set your own drpool accountname
accountname="accountname.miner001"

pids=$(ps -ef | grep dr_xnt_prover | grep -v grep | awk '{print $2}')
if [ -n "$pids" ]; then
    echo "$pids" | xargs kill
    sleep 5
fi

while true; do
    target=$(ps aux | grep dr_xnt_prover | grep -v grep)
    if [ -z "$target" ]; then
        ./dr_xnt_prover --pool stratum+tcp://xnt.drpool.io:30120 --worker $accountname -g 0
        sleep 5
    fi
    sleep 60
done