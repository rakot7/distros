#!/usr/bin/env bash
# HiveOS launcher for pcm-miner (single-file). Reads the flight-sheet wallet.conf
# (CUSTOM_URL / CUSTOM_TEMPLATE / CUSTOM_USER_CONFIG) and starts the miner.
# Output is teed to the log so h-stats.sh can read the periodic speed line.
set -o pipefail

WALLET_CONF="/hive-config/wallet.conf"
MINER_NAME="pcm-miner"
MINER_DIR="/hive/miners/custom/${MINER_NAME}"

[[ -f "${MINER_DIR}/h-manifest.conf" ]] && . "${MINER_DIR}/h-manifest.conf"
LOG_FILE="${CUSTOM_LOG_BASENAME:-/var/log/miner/${MINER_NAME}/${MINER_NAME}}.log"

# Match the CUDA device ordinal to nvidia-smi's index so --gpus and the
# h-stats temperatures line up.
export CUDA_DEVICE_ORDER=PCI_BUS_ID

mkdir -p "$(dirname "$LOG_FILE")"
cd "$MINER_DIR" || exit 1

read_conf() { grep "^${1}=" "$WALLET_CONF" 2>/dev/null | cut -d'=' -f2- | sed -e "s/^[\"']//; s/[\"']$//"; }

CUSTOM_URL="${CUSTOM_URL:-$(read_conf CUSTOM_URL)}"
CUSTOM_TEMPLATE="${CUSTOM_TEMPLATE:-$(read_conf CUSTOM_TEMPLATE)}"
CUSTOM_USER_CONFIG="${CUSTOM_USER_CONFIG:-$(read_conf CUSTOM_USER_CONFIG)}"

# Accept host:port and prepend the scheme pcm-miner expects.
[[ "$CUSTOM_URL" =~ :// ]] || CUSTOM_URL="stratum+tcp://${CUSTOM_URL}"

if [[ -z "$CUSTOM_URL" || -z "$CUSTOM_TEMPLATE" ]]; then
  echo "Missing CUSTOM_URL or CUSTOM_TEMPLATE in $WALLET_CONF" | tee -a "$LOG_FILE"
  exit 1
fi
if [[ ! -x ./${MINER_NAME} ]]; then
  echo "Missing executable $MINER_DIR/${MINER_NAME}" | tee -a "$LOG_FILE"
  exit 1
fi

cmd=(./"${MINER_NAME}"
  --algo pearl
  -o "$CUSTOM_URL"
  -u "$CUSTOM_TEMPLATE")

# Extra flags from the flight sheet, e.g. "--gpus 0,1,2" or "--cuda-sched blocking".
if [[ -n "$CUSTOM_USER_CONFIG" ]]; then
  read -r -a extra <<< "$CUSTOM_USER_CONFIG"
  cmd+=("${extra[@]}")
fi

echo "[$(date '+%F %T')] starting: ${cmd[*]}" | tee -a "$LOG_FILE"
exec "${cmd[@]}" 2>&1 | tee -a "$LOG_FILE"
