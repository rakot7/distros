#!/usr/bin/env bash
# HiveOS stats reader for pcm-miner. The minimal miner has no API: it prints a
# periodic line "gpuN X.X  ... | total T TH/s | shares A/R" — we parse the last
# one for hashrate/shares and read temps/fans from nvidia-smi. Sourced by the
# agent, so it only sets $khs and $stats (no echo/exit).
#
# Per-GPU display: HiveOS places each stats.hs value on a card ROW by matching
# stats.bus_numbers (PCI bus, decimal). Without bus_numbers the top summary shows
# the hs array but the per-card column stays empty. Pearl rates go out in kH/s
# (HiveOS clamps very large raw H/s for Pearl) — matches SRBMiner/fortune.

MINER_NAME="pcm-miner"
[[ -f "/hive/miners/custom/${MINER_NAME}/h-manifest.conf" ]] && . "/hive/miners/custom/${MINER_NAME}/h-manifest.conf"
LOG="${CUSTOM_LOG_BASENAME:-/var/log/miner/${MINER_NAME}/${MINER_NAME}}.log"

khs=0
stats="null"

line=$(grep -aE 'total [0-9.]+ TH/s \| shares [0-9]+/[0-9]+' "$LOG" 2>/dev/null | tail -1)
if [[ -n "$line" ]]; then
  # per-GPU hashrate in kH/s (TH/s ×1e9), in gpu0,gpu1,... order
  hs_json=$(echo "$line" | grep -oE 'gpu[0-9]+ [0-9.]+' | awk '{printf "%s%.0f", sep, $2*1e9; sep=","}')
  total=$(echo "$line" | sed -nE 's/.*total ([0-9.]+) TH.*/\1/p')
  acc=$(echo "$line"   | sed -nE 's#.*shares ([0-9]+)/[0-9]+.*#\1#p')
  rej=$(echo "$line"   | sed -nE 's#.*shares [0-9]+/([0-9]+).*#\1#p')
  khs=$(awk "BEGIN{printf \"%.0f\", ${total:-0}*1000000000}")  # TH/s -> kH/s

  # Telemetry from nvidia-smi (same PCI_BUS_ID order as --gpus all / hs[]).
  temp_json=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null | paste -sd, -)
  fan_json=$(nvidia-smi --query-gpu=fan.speed       --format=csv,noheader,nounits 2>/dev/null | paste -sd, -)
  # bus_numbers: decimal PCI bus per GPU, same order as hs[] — HiveOS maps each
  # per-GPU hashrate to the matching card row by this (e.g. 01->1, 0F->15).
  bus_json=""
  while IFS= read -r bid; do
    b="${bid#*:}"; b="${b%%:*}"
    [[ -n "$b" ]] && bus_json+="${bus_json:+,}$((16#$b))"
  done < <(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null)
  uptime=$(awk '{print int($1)}' /proc/uptime 2>/dev/null)

  stats=$(jq -cn \
    --argjson hs   "[${hs_json:-}]" \
    --argjson temp "[${temp_json:-}]" \
    --argjson fan  "[${fan_json:-}]" \
    --argjson bus  "[${bus_json:-}]" \
    --argjson acc  "${acc:-0}" \
    --argjson rej  "${rej:-0}" \
    --argjson uptime "${uptime:-0}" \
    --arg ver "${CUSTOM_VERSION:-0.0.1aa}" \
    '{hs:$hs, hs_units:"khs", temp:$temp, fan:$fan, bus_numbers:$bus, uptime:$uptime, ar:[$acc,$rej], algo:"pearl", ver:$ver}' \
    2>/dev/null)
fi

[[ -z "$khs" ]] && khs=0
[[ -z "$stats" || "$stats" == "null" ]] && stats="null"
