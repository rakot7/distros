#!/usr/bin/env bash
# Stop pcm-miner. The mining loop exits cleanly on SIGTERM.
MINER_NAME="pcm-miner"
pkill -x "$MINER_NAME" 2>/dev/null
sleep 1
pkill -9 -x "$MINER_NAME" 2>/dev/null
exit 0
