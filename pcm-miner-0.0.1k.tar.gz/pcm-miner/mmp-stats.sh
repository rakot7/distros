#!/usr/bin/env bash
# MMPOS stats hook for pcm-miner (Pearl). The agent calls:
#     mmp-stats.sh <GPU_COUNT> <LOG_FILE>
# and reads one JSON line on stdout. Nothing static here — everything comes from
# the live miner log and runtime GPU info.
#
# The miner prints a periodic line (internal/miner/run.go):
#     "<ts> gpu0 77.3  gpu1 53.8  | total 131.1 TH/s | shares 7/0"
# per-GPU TH/s in gpu0..N (CUDA/PCI_BUS_ID) order, cumulative accepted/rejected.
GPU_COUNT=$1
LOG_FILE=$2
cd "$(dirname "$0")" || exit 0
. mmp-external.conf

# NVIDIA (10de) PCI bus ids — same source/format the MMPOS agent expects.
# Verbatim approach from the reference dual archive (gpool-miner mmp-stats.sh).
get_bus_ids() {
    local vendor_id="$1"
    local gpu_info_json="/run/gpu-info.json"
    local busids=()
    if [[ -f "$gpu_info_json" ]]; then
        local vendor
        vendor_id=$(echo "$vendor_id" | tr -d '[:space:]')
        case "$vendor_id" in
            10de) vendor="nvidia" ;;
            1002) vendor="amd_sysfs" ;;
            *)    vendor="intel_sysfs" ;;
        esac
        local bus_ids
        bus_ids=$(jq -r ".device.GPU.${vendor}_details.busid[]" "$gpu_info_json" 2>/dev/null)
        [[ -z "$bus_ids" ]] && exit 1
        while read -r bus_id; do
            local hex=${bus_id:5:2}
            busids+=($((16#$hex)))
        done <<< "$bus_ids"
    else
        local bus_ids
        bus_ids=$(/bin/lspci -n | awk '$2 ~ /^030[02]:/ && $3 ~ /^'"$vendor_id"':/ {print $1}')
        [[ -z "$bus_ids" ]] && exit 1
        while read -r bus_id; do
            local decimal_bus_id=$((16#${bus_id%%:*}))
            busids+=("$decimal_bus_id")
        done <<< "$bus_ids"
    fi
    echo "${busids[*]}"
}

# Report nothing (agent shows offline) if the log is stale or disconnected.
maxDelay=120
[[ ! -f "$LOG_FILE" ]] && exit 0
(( $(date +%s) > $(stat -c %Y "$LOG_FILE") + maxDelay )) && exit 0
tail -n 10 "$LOG_FILE" | grep -qiE 'disconnect' && exit 0

# Last periodic stats line (strip ANSI just in case).
line=$(sed -r 's/\x1B\[[0-9;]*[mK]//g' "$LOG_FILE" 2>/dev/null \
        | grep -aE 'total [0-9.]+ TH/s \| shares [0-9]+/[0-9]+' | tail -1)
[[ -z "$line" ]] && exit 0

# Per-GPU TH/s in gpu0..N order; cumulative accepted/rejected.
mapfile -t hs < <(echo "$line" | grep -oE 'gpu[0-9]+ [0-9.]+' | awk '{print $2}')
acc=$(echo "$line" | sed -nE 's#.*shares ([0-9]+)/[0-9]+.*#\1#p'); acc=${acc:-0}
rej=$(echo "$line" | sed -nE 's#.*shares [0-9]+/([0-9]+).*#\1#p'); rej=${rej:-0}

read -ra busid <<< "$(get_bus_ids "10de")"

jq -nc \
    --argjson hash  "$(printf '%s\n' "${hs[@]}"    | jq -cs '.')" \
    --argjson busid "$(printf '%s\n' "${busid[@]}" | jq -cs '.')" \
    --arg units "ths" \
    --arg ac "$acc" --arg inv "0" --arg rj "$rej" \
    --arg miner_version "$EXTERNAL_VERSION" \
    --arg miner_name "$EXTERNAL_NAME" \
    '{$busid, $hash, $units, air: [$ac, $inv, $rj], miner_name: $miner_name, miner_version: $miner_version}'
