#!/usr/bin/env bash
# pcm-miner takes all its config from the flight sheet (wallet.conf) at launch
# via h-run.sh, so there is no separate config file to generate.
exit 0
