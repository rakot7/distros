#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1

# Wallet/address comes from flight sheet template field.
conf="--host 84.32.220.219:9000"
conf+=" --user ${CUSTOM_TEMPLATE}"
conf+=" ${CUSTOM_USER_CONFIG}"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > "$CUSTOM_CONFIG_FILENAME"
